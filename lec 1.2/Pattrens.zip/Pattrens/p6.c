#include<stdio.h>

main(){
	
	printf("\t*                 *\n");
	printf("\t  *             *  \n");
	printf("\t    *         *    \n");
	printf("\t      *     *      \n");
	printf("\t        *  *       \n");
	printf("\t         *         \n");
	printf("\t        *  *       \n");
	printf("\t      *     *      \n");
	printf("\t    *         *    \n");
	printf("\t  *             *  \n");
	printf("\t*                 *\n");
	
}
