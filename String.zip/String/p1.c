#include<stdio.h>
main(){
	
	char str[] = "hello world";
	
	printf("Enter Of Any String :- %s \n",str);
	
	printf("Uppercase string :- %s",strupr(str));
}
