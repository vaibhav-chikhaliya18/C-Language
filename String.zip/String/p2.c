#include<stdio.h>
main(){
	char str[] = "HELLO WORLD";
	
	printf("Enter Of Any String :- %s \n",str);
	
	printf("Lowercase string :- %s",strlwr(str));
}
