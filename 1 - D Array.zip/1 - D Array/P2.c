#include<stdio.h>
 main(){
	int f,l,i,arr[i];
	printf("Enter Of first year:-");
	scanf("%d",&f);
	
	printf("Enter Of Last year:-");
	scanf("%d",&l);
	
	for(arr[i]=f; arr[i]<=l; arr[i]++){
		if(arr[i] % 4== 0){
			printf("%d,",arr[i]);
		}
	}
}
