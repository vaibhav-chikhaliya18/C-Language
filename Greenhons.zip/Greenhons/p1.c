#include<stdio.h>

main(){
	
	int c,f;
	
	printf("enter your degree celcius : ");
	scanf("%d",&c);
	
	f=(c*9/5)+32;
	printf("%d",f);	
}
