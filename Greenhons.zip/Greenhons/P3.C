#include<stdio.h>

main(){
	
	float angle1,angle2,angle3;
	
	printf("Enter Your First angle : ");
	scanf("%f",&angle1);
	
	printf("Enter Your First angle : ");
	scanf("%f",&angle1);
	
	angle3 = 180 - (angle1 + angle2);
	
	printf("Third angle : %.2f\n",angle3);
	
}
